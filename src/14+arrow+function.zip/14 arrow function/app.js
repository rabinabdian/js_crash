const greeting = (firstName, lastName) => console.log(`Hello, my name is ${firstName} ${lastName}`)



greeting('Tom', 'Smith')